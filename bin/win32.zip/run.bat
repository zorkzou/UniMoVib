unimovib.exe -b <job.inp >job.out
